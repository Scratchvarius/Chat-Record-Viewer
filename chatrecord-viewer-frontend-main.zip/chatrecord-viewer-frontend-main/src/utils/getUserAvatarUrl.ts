export default function getUserAvatarUrl(uin:number){
    return `https://q1.qlogo.cn/g?b=qq&nk=${uin}&s=140`
}
